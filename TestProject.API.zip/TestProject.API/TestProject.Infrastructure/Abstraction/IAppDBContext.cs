﻿
using Microsoft.EntityFrameworkCore;
using TestProject.Model;

namespace TestProject.Infrastructure
{
    public interface IAppDBContext
    {
        DbSet<User> Users { get; set; }
        DbSet<Account> Accounts { get; set; }
        Task<int> SaveChangesAsync();
    }
}
