﻿using Microsoft.EntityFrameworkCore;
using TestProject.Model;

namespace TestProject.Infrastructure
{
    public class AppDbContext : DbContext, IAppDBContext
    {
        private readonly DateTime _currentDateTime;
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
            _currentDateTime = DateTime.Now;
        }

        public DbSet<User> Users { get; set; }

        public DbSet<Account> Accounts { get; set; }

        public Task<int> SaveChangesAsync()
        {
           return base.SaveChangesAsync();
        }
    }
}
