﻿using TestProject.Model;
using TestProject.Infrastructure;

namespace TestProject.Core
{
    public class AccountRepository : IAccountRepository
    {
        private readonly IAppDBContext _appDBContext;

        public AccountRepository(IAppDBContext appDBContext)
        {
            _appDBContext = appDBContext;
        }


        /// <summary>
        /// Get all accounts's list for a user
        /// </summary>
        /// <returns>IEnumerable<User></returns>
        public IEnumerable<Account> GetAccountList(int id)
        {
            IEnumerable<Account> accounts = _appDBContext.Accounts.Where(a => a.UserId == id);
            return accounts;
        }

        /// <summary>
        /// Get account's detail by id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>User Details</returns>
        public Account GetAccount(int id)
        {
            Account account = _appDBContext.Accounts.Where(a=>a.AccountId == id).FirstOrDefault();
            return account;
        }

        /// <summary>
        /// Add account to the list
        /// </summary>
        /// <param name="user"></param>
        /// <returns>bool</returns>
        public bool AddAccount(Account account)
        {
            return _appDBContext.AddAccount(account);
        }
    }
}
