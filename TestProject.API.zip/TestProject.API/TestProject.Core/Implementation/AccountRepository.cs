﻿using TestProject.Model;

namespace TestProject.Core
{
    public class AccountRepository : IAccountRepository
    {
        /// <summary>
        /// Get all accounts's list for a user
        /// </summary>
        /// <returns>IEnumerable<User></returns>
        public IEnumerable<Account> GetAccountList(int id)
        {
            IEnumerable<Account> accounts = new List<Account>();
            return accounts;
        }

        /// <summary>
        /// Get account's detail by id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>User Details</returns>
        public User GetAccount(int id)
        {
            User user = new User();
            return user;
        }

        /// <summary>
        /// Add account to the list
        /// </summary>
        /// <param name="user"></param>
        /// <returns>bool</returns>
        public bool AddAccount(Account user)
        {
            return false;
        }
    }
}
