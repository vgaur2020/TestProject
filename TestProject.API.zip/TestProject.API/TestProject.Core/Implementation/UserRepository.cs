﻿using TestProject.Model;
using TestProject.Infrastructure;

namespace TestProject.Core
{
    public class UserRepository: IUserRepository
    { 
        private IAppDBContext _appDbContext { get; set; }

        public UserRepository(IAppDBContext appDBContext)
        { 
            _appDbContext = appDBContext;
        }
        /// <summary>
        /// Get all user's list
        /// </summary>
        /// <returns>IEnumerable<User></returns>
        public IEnumerable<User> GetUserList() 
        {
            IEnumerable<User> users = _appDbContext.Users.Where(u=>!u.IsDeleted).ToList();
            return users;
        }
        
        /// <summary>
        /// Get user's detail by id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>User Details</returns>
        public User GetUser(int id)
        {
            User user = _appDbContext.Users.Where(u => u.Id == id).FirstOrDefault();
            return user;
        }

        /// <summary>
        /// Add user to the list
        /// </summary>
        /// <param name="user"></param>
        /// <returns>bool</returns>
        public bool AddUser(User user)
        {
            return _appDbContext.AddUser(user);             
        }

        /// <summary>
        /// Is User already Exists
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool IsUserExists(string emailId)
        {
            return _appDbContext.Users.Contains(_appDbContext.Users.Where(u => u.Email.Trim() == emailId.Trim()).FirstOrDefault());
        }
    }
}
