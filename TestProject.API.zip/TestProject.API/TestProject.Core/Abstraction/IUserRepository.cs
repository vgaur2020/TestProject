﻿using TestProject.Model;

namespace TestProject.Core
{
    public interface IUserRepository
    {
        /// <summary>
        /// Get List of Available/Active Users
        /// </summary>
        /// <returns>IEnumerable<User></returns>
        IEnumerable<User> GetUserList();

        /// <summary>
        /// Get user's detail by id.
        /// </summary>
        /// <param name="id">User's id</param>
        /// <returns>User</returns>
        User GetUser(int id);

        /// <summary>
        /// Add User to the list
        /// </summary>
        /// <param name="user">User user</param>
        /// <returns>bool</returns>
        bool AddUser(User user);

        /// <summary>
        /// Check If User Already Exists
        /// </summary>
        /// <param name="emailId"></param>
        /// <returns></returns>
        bool IsUserExists(string emailId);
    }
}
