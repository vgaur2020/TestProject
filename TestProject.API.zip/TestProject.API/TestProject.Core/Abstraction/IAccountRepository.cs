﻿using TestProject.Model;

namespace TestProject.Core
{
    public interface IAccountRepository
    {
        /// <summary>
        /// Get List of Available/Active Users
        /// </summary>
        /// <returns>IEnumerable<User></returns>
        IEnumerable<Account> GetAccountList(int id);

        /// <summary>
        /// Get user's detail by id.
        /// </summary>
        /// <param name="id">User's id</param>
        /// <returns>User</returns>
        User GetAccount(int id);

        /// <summary>
        /// Add User to the list
        /// </summary>
        /// <param name="user">User user</param>
        /// <returns>bool</returns>
        bool AddAccount(Account user);
    }
}
