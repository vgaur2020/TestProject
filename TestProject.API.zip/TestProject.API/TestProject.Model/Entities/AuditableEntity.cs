﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject.Model
{
    public abstract class AuditableEntity : IAuditableEntity
    {
        /// <summary>
        /// Is Entity Deleted
        /// </summary>
        public bool IsDeleted { get; set; } = false;

        /// <summary>
        /// Entity Created On
        /// </summary>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Entity Last Modified On
        /// </summary>
        public DateTime LastModifiedOn { get; set; }
    }
}
