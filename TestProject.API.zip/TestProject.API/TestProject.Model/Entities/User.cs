﻿using System.ComponentModel.DataAnnotations;

namespace TestProject.Model
{
    public class User: AuditableWithBaseEntity<int>
    {
        /// <summary>
        /// User's Name
        /// </summary>
        [Required(ErrorMessage = "Please enter name")]
        [StringLength(100)]
        public string Name { get; set; }

        /// <summary>
        /// User's Email
        /// </summary>
        [Required(ErrorMessage = "Please enter email address")]
        [Display(Name = "Email Address")]
        [EmailAddress]
        public string Email { get; set; }

        /// <summary>
        /// User's Monthly Salary
        /// </summary>        
        [Required(ErrorMessage = "Please enter Monthly Salary")]       
        public float MonthlySalary { get; set; }

        /// <summary>
        /// User's Monthly Expense
        /// </summary>
        [Required(ErrorMessage = "Please enter Monthly Expense")]
        [ValidMonthlyExpense(ErrorMessage = "Monthly Expense can not be greater than Monthly Salary.")]
        public float MonthlyExpense { get; set; }
    }
}