﻿
using System.ComponentModel.DataAnnotations.Schema;

namespace TestProject.Model
{
    public class Account : AuditableEntity
    {
        /// <summary>
        /// Account Name
        /// </summary>
        public string AccountName { get; set; }

        /// <summary>
        /// Account Id
        /// </summary>
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AccountId { get; set; }
        /// <summary>
        /// Balance
        /// </summary>
        public float Balance { get; set; }

        /// <summary>
        /// User Id
        /// </summary>
        public int UserId { get; set; }
    }
}
