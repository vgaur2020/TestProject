﻿
namespace TestProject.Model
{
    public class Account:AuditableWithBaseEntity<int>
    {
        /// <summary>
        /// Account Name
        /// </summary>
        public string AccountName { get; set; }
        /// <summary>
        /// Account Id
        /// </summary>
        public int AccountId { get; set; }
        /// <summary>
        /// Balance
        /// </summary>
        public float Balance { get; set; }
    }
}
