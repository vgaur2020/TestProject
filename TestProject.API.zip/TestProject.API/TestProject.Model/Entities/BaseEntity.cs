﻿

namespace TestProject.Model
{
    public abstract class BaseEntity<T>
    {
        /// <summary>
        /// Unique ID
        /// </summary>
        public virtual T Id { get; set; }
    }
}
