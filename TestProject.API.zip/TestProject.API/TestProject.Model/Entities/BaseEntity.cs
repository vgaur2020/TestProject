﻿using System.ComponentModel.DataAnnotations.Schema;

namespace TestProject.Model
{
    public abstract class BaseEntity<T>
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        /// <summary>
        /// Unique ID
        /// </summary>
        public virtual T Id { get; set; }
    }
}
