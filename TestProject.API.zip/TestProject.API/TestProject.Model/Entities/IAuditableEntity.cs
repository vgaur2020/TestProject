﻿namespace TestProject.Model
{
    public interface IAuditableEntity
    {
        /// <summary>
        /// Is Entity Deleted
        /// </summary>
        bool IsDeleted { get; set; }

        /// <summary>
        /// Entity Created On
        /// </summary>
        DateTime CreatedOn { get; set; }

        /// <summary>
        /// Entity Last Modified On
        /// </summary>
        DateTime LastModifiedOn { get; set; }
    }
}
