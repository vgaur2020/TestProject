﻿namespace TestProject.Model
{
    public abstract class AuditableWithBaseEntity<T> : BaseEntity<T>, IAuditableEntity
    {
        /// <summary>
        /// Is Entity Deleted
        /// </summary>
        public bool IsDeleted { get; set; } = false;

        /// <summary>
        /// Entity Created On
        /// </summary>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Entity Last Modified On
        /// </summary>
        public DateTime LastModifiedOn { get; set; }
    }
}
