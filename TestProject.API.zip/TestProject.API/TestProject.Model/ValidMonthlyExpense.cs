﻿using System.ComponentModel.DataAnnotations;

namespace TestProject.Model
{
    internal class ValidMonthlyExpense:ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var model = (User)validationContext.ObjectInstance;

            if (model.MonthlyExpense > model.MonthlySalary)
            {
                return new ValidationResult("Monthly Expense can not be greater than Monthly Salary.");
            }
            else
                return ValidationResult.Success;
        }
    }
}
