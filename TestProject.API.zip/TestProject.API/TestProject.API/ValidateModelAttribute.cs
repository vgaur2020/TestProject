﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace TestProject.API
{
    public class ValidateModelAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.ModelState.IsValid)
            {                
                    var errors = context.ModelState.Where(a => a.Value.Errors.Count > 0)
                        .SelectMany(x => x.Value.Errors)
                        .ToList();                                   
                context.Result = new BadRequestObjectResult(errors);
            }
        }
    }
}
