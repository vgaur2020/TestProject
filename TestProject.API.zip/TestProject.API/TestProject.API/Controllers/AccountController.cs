﻿using Microsoft.AspNetCore.Mvc;
using TestProject.Model;
using TestProject.Core;

namespace TestProject.API.Controllers
{
    [ApiController]
    [ValidateModelAttribute]
    [Route("api/[controller]/[action]")]
    public class AccountController : ControllerBase
    {
        private IAccountRepository _account; 

        public AccountController(IAccountRepository userDetails)
        {
            _account = userDetails;
        }

        /// <summary>
        /// Get list of all available/active users.
        /// </summary>
        /// <returns>IEnumerable<User></returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<User>))]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public IEnumerable<Account> GetAccountListForUser(int id) => _account.GetAccountList(id);

        /// <summary>
        /// Get user's detail by the id.
        /// </summary>
        /// <param name="id">int id</param>
        /// <returns>User</returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(User))]
        public IActionResult GetAccount(int id)
        {
            if (id == null)
                return BadRequest();

            var user = _account.GetAccount(id);
            if (user == null) return NotFound();

            return Ok(user);
        }

        /// <summary>
        /// Post the User Details
        /// </summary>
        /// <returns>IActionResult</returns>
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public IActionResult Post(Account account)
        {
            if (account == null)
                return BadRequest();

            return Ok(_account.AddAccount(account));
        }
    }
}
