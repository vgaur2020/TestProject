﻿using Microsoft.AspNetCore.Mvc;
using TestProject.Model;
using TestProject.Core;

namespace TestProject.API.Controllers
{
    [ApiController]
    [ValidateModelAttribute]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private IUserRepository _user;

        public UserController(IUserRepository userDetails)
        {            
            _user = userDetails;
        }

        /// <summary>
        /// Get list of all available/active users.
        /// </summary>
        /// <returns>IEnumerable<User></returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<User>))]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public IEnumerable<User> Get() =>  _user.GetUserList();

        /// <summary>
        /// Get user's detail by the id.
        /// </summary>
        /// <param name="id">int id</param>
        /// <returns>User</returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(User))]
        public IActionResult Get(int id)
        {
            if (id == null) 
                return BadRequest();

            var user = _user.GetUser(id);            
            if (user == null)   return NotFound();

            return Ok(user);
        }

        /// <summary>
        /// Post the User Details
        /// </summary>
        /// <returns>IActionResult</returns>
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public IActionResult Post(User user)
        {
            if (user == null)
                return BadRequest();

            //if (!_user.IsUserExists(user.Email))
                _user.AddUser(user);
            //else
            //    return BadRequest("User Already Exists");
            return Ok("User successfully added.");
        }
    }
}
